
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// ../site-monitor/functions/weekly.mjs
var PAT = process.env.NETLIFY_PAT;
var SITE_ID = process.env.NETLIFY_SITE_ID;
var BRANCH = "lane/monitor";
var weekly_default = async (req) => {
  const out = { fired: (/* @__PURE__ */ new Date()).toISOString(), site: SITE_ID, branch: BRANCH };
  if (!PAT || !SITE_ID) {
    out.error = "NETLIFY_PAT / NETLIFY_SITE_ID not set";
    return new Response(JSON.stringify(out), { status: 500 });
  }
  try {
    const r = await fetch(`https://api.netlify.com/api/v1/sites/${SITE_ID}/builds`, {
      method: "POST",
      headers: { Authorization: `Bearer ${PAT}`, "Content-Type": "application/json" },
      body: JSON.stringify({ branch: BRANCH }),
      signal: AbortSignal.timeout(3e4)
    });
    const j = await r.json().catch(() => ({}));
    out.build_id = j.id;
    out.http = r.status;
  } catch (e) {
    out.error = String(e).slice(0, 120);
  }
  return new Response(JSON.stringify(out), { status: 200 });
};
var config = { schedule: "0 9 * * 1", path: "/api/weekly" };
export {
  config,
  weekly_default as default
};
